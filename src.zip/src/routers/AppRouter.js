import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Header from '../components/Header';
import DashBoard from '../components/DashBoard';
import NotFound from '../components/NotFound';
//import AddBook from '../components/AddBook';
import AddFeedback from '../components/AddFeedback';
//import EditBook from '../components/EditBook';
import EditFeedback from '../components/EditFeedback';
import SearchByUser from '../components/SearchbyUser';

const AppRouter = () => (
    <BrowserRouter>
        <div className='container'>
            <Header />
            <Switch>
                <Route path="/" component={DashBoard} exact={true} />                              
                <Route path="/add" component={AddFeedback} />
                <Route path="/usersearch" component={SearchByUser} /> */}
                <Route component={NotFound} />
            </Switch>
        </div>
    </BrowserRouter>
);

export default AppRouter;