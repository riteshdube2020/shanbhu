// import React from 'react';
// import { connect } from 'react-redux';
// //import Book from './Book';
// import Feedback from './Feedback';
// //import FeedbackList from './FeedbackList';
// import feedbacks from '../actions/feedbacks';


// export default class UsersearchList extends React.Component{

//     constructor(props) {
//         super(props);
//         this.handleClick = this.handleClick.bind(this);
        
//         this.state = {
//             userid:"rd41177"            
//     }
// }

//     handleClick(){
//         this.setState({
//             userid:""
//     })
//         props.dispatch(getUsersearch(this.state.userid));

//     }

// render() {
//     return (
//         <div> 
//             <input type="text" placeholder="User-ID" 
//             value={this.state.userid}>
//                 </input> 
//             <button onClick={'handleClick'}>Search</button>              
//         </div>
//     );

//     }
// }

//  connect()(UsersearchList);





