import React from 'react';
//import BookForm from './BookForm';
import FeedbackForm from './FeedbackForm';
import { connect } from 'react-redux';
//import { addBook } from '../actions/books';
import { addFeedback } from '../actions/feedbacks';

const AddFeedback = (props) => (
    <div>
        <h3>Add Feedback information:</h3>
        <FeedbackForm
            onSubmitFeedback={(feedback) => {
                props.dispatch(addFeedback(feedback));
                props.history.push('/');
            }}
        />
    </div>
);

export default connect()(AddFeedback);
