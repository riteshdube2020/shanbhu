import React from 'react';
import { NavLink } from 'react-router-dom';
import { alert, buttons, jumbotron } from 'bootstrap-css';

const Header = () => (
    <header>
        {/* <h2>Capstone Project : User Feedback</h2> */}
        <h2><a href="#" class="navbar-link"><p  class="section-heading text-center" >Capstone Project: User Feedback</p></a></h2>
        <h6 class="section-heading text-center" color>Feedback Mangement Application: Ritesh S Dube</h6>
         <br></br>
         <br></br>
        
        {/* <div className='header__nav'>
            <NavLink to='/' activeClassName='activeNav' exact={true}>Dashboard</NavLink>&nbsp; &nbsp; &nbsp;&nbsp;
            <NavLink to='/add' activeClassName='activeNav'>Add-Feedback</NavLink>      &nbsp; &nbsp; &nbsp;&nbsp;     &nbsp;
            <NavLink to='/usersearch' activeClassName='activeNav'>Search By User</NavLink>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
            <NavLink to='/ratingsearch' activeClassName='activeNav'>Search By Rating</NavLink>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
        </div> */}

<div className='header__nav'>
			<ul class="nav nav-pills">
            <li role="presentation" class="active"><a href="#"><NavLink to='/' activeClassName='activeNav' exact={true}>Dashboard</NavLink></a></li>&nbsp; &nbsp; &nbsp;&nbsp;
            <li role="presentation"><a href="#"><NavLink to='/add' activeClassName='activeNav'>Add-Feedback</NavLink> </a></li>     &nbsp; &nbsp; &nbsp;&nbsp;     &nbsp;
            <li role="presentation"><a href="#"><NavLink to='/usersearch' activeClassName='activeNav'>Search By User</NavLink></a></li>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
            <li role="presentation"><a href="#"><NavLink to='/ratingsearch' activeClassName='activeNav'>Search By Rating</NavLink></a></li>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
			</ul>
        </div>
    </header>


);

export default Header;