import React from 'react';
import InputRange from 'react-input-range';
import { alert, buttons, jumbotron } from 'bootstrap-css';


export default class FeedbackForm extends React.Component {
    constructor(props) {
        super(props);
        this.onTitleChange = this.onTitleChange.bind(this);
        this.onUseridChange = this.onUseridChange.bind(this);
        this.onReviewChange = this.onReviewChange.bind(this);
        this.onRatingChange = this.onRatingChange.bind(this);
        this.onSourceChange = this.onSourceChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            title: props.feedback ? props.feedback.title : '',
            userid: props.feedback ? props.feedback.userid : '',
            review: props.feedback ? props.feedback.review : '',
            rating: props.feedback ? props.feedback.rating : '',
            source: props.feedback ? props.feedback.source : '',

            error: ''
        };
    }

    onTitleChange(e) {
        const title = e.target.value;
        this.setState(() => ({ title: title }));
    }

    onUseridChange(e) {
        const userid = e.target.value;
        this.setState(() => ({ userid: userid }));
    }

    onReviewChange(e) {
        const review = e.target.value;
        this.setState(() => ({ review: review }));
    }

    onRatingChange(e) {
        const rating = parseInt(e.target.value);
        this.setState(() => ({ rating: rating }));
    }

    onSourceChange(e) {
        const source = e.target.value;
        this.setState(() => ({ source: source }));
    }

    onSubmit(e) {
        e.preventDefault();

        if (!this.state.title || !this.state.userid || !this.state.review  || !this.state.source  || !this.state.rating) {
            this.setState(() => ({ error: 'Please set title & userid & review!' }));
        } else {
            // alert('in else feedback');
            this.setState(() => ({ error: '' }));
            this.props.onSubmitFeedback(
                {
                    
                    title: this.state.title,
                    userid: this.state.userid,
                    review: this.state.review,
                    rating: this.state.rating,
                    source: this.state.source
                }
                
            );
        }
    }

    render() {
        return (

    <div class="dropdown"> 
          
  <button class="btn btn-default dropdown-toggle" type="button" 
  id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
    Rating
    <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
    <li><a href="#">1</a></li>
    <li><a href="#">2</a></li>
    <li><a href="#">3 </a></li>
	<li><a href="#">4 </a></li>
	<li><a href="#">5 </a></li>
    <li role="separator" class="divider"></li>
    <li><a href="#">Separated link</a></li>
  </ul>            
                {this.state.error && <p className='error'>{this.state.error}</p>}
                <form onSubmit={this.onSubmit} className='add-feedback-form'>           
                  {/* <span class="input-group-addon" id="basic-addon1">Title</span>
                  <input type="text" class="form-control" placeholder="Title" aria-describedby="basic-addon1"></input> */}
                    <input type="text"  placeholder="Title" 
                        value={this.state.title}
                        onChange={this.onTitleChange} />
                        <br />
                    <input type="text"  placeholder="User-Id" 
                        value={this.state.userid}
                        onChange={this.onUseridChange} />
                    <br />
                    <input type="text" placeholder="Source" autoFocus
                        value={this.state.source}
                        onChange={this.onSourceChange} />
                    <br />

                    <textarea required rows ='5' cols="60" placeholder="Enter Feedback" 
                        value={this.state.review}
                        onChange={this.onReviewChange} />
                    <br />
                    <input type="number" placeholder="rating" InputRange max= '5' 
                        value={this.state.rating}
                        onChange={this.onRatingChange} />
                    <br />           
                    <button>AddFeeback</button>
                </form>

                
            </div>

            
        );
    }
}